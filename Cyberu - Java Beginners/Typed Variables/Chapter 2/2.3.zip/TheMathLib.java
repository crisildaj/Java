package themathlib;

import java.lang.Math;

public class TheMathLib {
    public static void main(String[] args) {
        double number = 4.321;
        number = Math.pow(number, 4.0);
        System.out.println(number);
    }
}
