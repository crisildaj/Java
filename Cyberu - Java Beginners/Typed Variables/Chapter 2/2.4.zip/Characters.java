package characters;

public class Characters {
    public static void main(String[] args) {
        char character1 = 'H';
        char character2 = 9;
        char character3 = 9;
        char character4 = 9;
        char character5 = 'o';
        
        System.out.print(character1);
        System.out.print(character2);
        System.out.print(character3);
        System.out.print(character4);
        System.out.println(character5);
    }
}