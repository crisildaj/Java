
package floatingpointnumbers;

public class FloatingPointNumbers {
    public static void main(String[] args) {
        
       int iNumber1 = 5;
       int iNumber2 = 6;
       float fNumber = (float)iNumber1/iNumber2;
       
       System.out.println(fNumber);
        
    }
}
