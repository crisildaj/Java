class HelloWorld {
    static void main(String[] args) {
        println "Hello World"

        // Define a typed variable
        int age = 40

        // Print variable value
        println age

        // Print variable type
        println age.getClass()

        // Define a variable with dynamic typing
        def name = "John"

        // Print variable value
        println name

        // Print variable type
        println name.getClass()
    }
}