class HelloWorld {
    static void main(String[] args) {
        Person johnDoe = new Person()
        johnDoe.setFirstName("John")
        johnDoe.setLastName("Doe")
        johnDoe.setAge(40)

        // Create Closure that prints String representation of a person

        // Pass Closure to a method and execute it

        // Create Closure that prints full name of a person
    }
}