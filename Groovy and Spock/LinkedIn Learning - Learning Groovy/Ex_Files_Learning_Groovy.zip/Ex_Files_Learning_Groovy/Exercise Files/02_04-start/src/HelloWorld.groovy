class HelloWorld {
    static void main(String[] args) {
        Person johnDoe = new Person()
        johnDoe.setFirstName("John")
        johnDoe.setLastName("Doe")
        johnDoe.setAge(40)
        println johnDoe.getFullName()
        println johnDoe.getAge()

        // Identify if Person is middle-aged using a conditional

        // Define a list of Persons

        // Iterate over Person instances in list
    }
}