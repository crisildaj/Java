import groovy.transform.ToString

@ToString
class Person {
    String firstName
    String lastName
    int age
}
