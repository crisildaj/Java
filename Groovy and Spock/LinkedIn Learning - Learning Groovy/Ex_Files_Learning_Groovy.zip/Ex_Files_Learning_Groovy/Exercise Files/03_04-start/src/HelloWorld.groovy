class HelloWorld {
    static void main(String[] args) {
        Person johnDoe = new Person()

        // Read full contents of file

        // Iterate over each line of file
    }
}