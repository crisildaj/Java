class HelloWorld {
    static void main(String[] args) {
        // Create new Person class and instantiate it

        // Print the full name and age of Person instance
    }
}