class HelloWorld {
    static void main(String[] args) {
        // Create a file and populate contents
        File textFile = new File("resources/mary-hill.txt")

        // Appending contents to a file

        // Serializing an object to a file
        Person thomasMarks = new Person("Thomas", "Marks", 21)
        File binFile = new File("resources/thomas-marks.bin")
    }
}