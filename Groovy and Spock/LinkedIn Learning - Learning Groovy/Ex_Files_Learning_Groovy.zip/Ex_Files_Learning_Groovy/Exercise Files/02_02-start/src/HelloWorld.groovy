class HelloWorld {
    static void main(String[] args) {
        println "Hello World"

        // Define a typed variable

        // Print variable value

        // Print variable type

        // Define a variable with dynamic typing

        // Print variable value

        // Print variable type
    }
}