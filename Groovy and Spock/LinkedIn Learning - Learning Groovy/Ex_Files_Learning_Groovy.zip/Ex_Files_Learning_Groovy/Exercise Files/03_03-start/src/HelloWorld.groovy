class HelloWorld {
    static void main(String[] args) {
        Person johnDoe = new Person("John", "Doe", 40)
        Person maryHill = new Person("Mary", "Hill", 30)
        Person thomasMarks = new Person("Thomas", "Marks", 21)

        // Create a new list of persons

        // Querying Collections

        // Iterate over elements

        // Iterate over elements and using an index

        // Filtering a specific element

        // Transforming elements into something else

        // Sorting elements based on a criterion
    }
}