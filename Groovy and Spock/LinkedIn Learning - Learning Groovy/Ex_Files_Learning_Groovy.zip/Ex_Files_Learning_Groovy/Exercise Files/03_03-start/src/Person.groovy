import groovy.transform.Canonical

@Canonical
class Person {
    String firstName
    String lastName
    int age
}
