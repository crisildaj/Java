class Person {
    String firstName
    String lastName
    int age

    String getFullName() {
        firstName + " " + lastName
    }
}
